<?php

namespace OCA\PasswordsEncryptionProvider\AppInfo;

use OC;
use OCA\Passwords\Encryption\Object\SseV3KeyProviderInterface;
use OCA\PasswordsEncryptionProvider\Encryption\KeyProvider;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;

/**
 * Class Application
 *
 * @package OCA\Test\AppInfo
 */
class Application extends App implements IBootstrap {

    /**
     * Application constructor.
     *
     * @param array $urlParams
     */
    public function __construct(array $urlParams = []) {
        parent::__construct('passwords_encryption_provider', $urlParams);
    }

    /**
     * @param IRegistrationContext $context
     */
    public function register(IRegistrationContext $context): void {
        OC::$server->registerService(
            SseV3KeyProviderInterface::class,
            function() {
                return new KeyProvider();
            }
        );
    }

    /**
     * @param IBootContext $context
     */
    public function boot(IBootContext $context): void {
    }

}
