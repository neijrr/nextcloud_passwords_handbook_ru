<?php

namespace OCA\PasswordsEncryptionProvider\AppInfo;

use OC;
use OCA\Passwords\Encryption\Object\SseV3KeyProviderInterface;
use OCA\PasswordsEncryptionProvider\Encryption\CustomKeyProvider;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\IConfig;
use OCP\Security\ICrypto;
use OCP\Security\ISecureRandom;
use Psr\Container\ContainerInterface;

/**
 * Class Application
 *
 * @package OCA\Test\AppInfo
 */
class Application extends App implements IBootstrap {

    /**
     * Application constructor.
     *
     * @param array $urlParams
     */
    public function __construct(array $urlParams = []) {
        parent::__construct('passwords_encryption_provider', $urlParams);
    }

    /**
     * @param IRegistrationContext $context
     */
    public function register(IRegistrationContext $context): void {
        OC::$server->registerService(
            SseV3KeyProviderInterface::class,
            function (ContainerInterface $c) {
                return new CustomKeyProvider(
                    'passwords_encryption_provider',
                    $c->get(ISecureRandom::class),
                    $c->get(IConfig::class),
                    $c->get(ICrypto::class)
                );
            }
        );
    }

    /**
     * @param IBootContext $context
     */
    public function boot(IBootContext $context): void {
    }

}
