<?php

namespace OCA\PasswordsEncryptionProvider\Encryption;

use OCA\Passwords\Encryption\Object\SseV3KeyProviderInterface;
use OCA\Passwords\Services\ConfigurationService;
use OCA\Passwords\Services\EnvironmentService;
use OCP\IConfig;
use OCP\Security\ICrypto;
use OCP\Security\ISecureRandom;

class CustomKeyProvider implements SseV3KeyProviderInterface {

    const KEY_LENGTH  = 1024;
    const CONFIG_PATH = 'pw_user_key';

    /**
     * This array is used to cache decrypted user keys within a single request.
     * This cache does not mean that something is stored somewhere,
     * it just means that we don't need to derypt the key every time it's used within the same request.
     * E.g. if the user wants to list all their passwords, the passwords app will request the user key
     * for every password. This cache ensures that we only have to decrypt it once.
     *
     * @var string[]
     */
    private array $userKeyCache = [];

    /**
     * @param string        $appName
     * @param ISecureRandom $secureRandom
     * @param IConfig       $config
     * @param ICrypto       $crypto
     */
    public function __construct(protected string $appName, protected ISecureRandom $secureRandom, protected IConfig $config, protected ICrypto $crypto) {
    }

    /**
     * This function returns true if the provider is ready to be used
     *
     * @return bool
     */
    public function isAvailable(): bool {
        /**
         * This provider is capable of generating keys if the server secret is set
         */
        return !empty($this->config->getSystemValue('secret'));
    }

    /**
     * This function provides the general encryption key for the given user
     *
     * @param string $userId
     *
     * @return string
     * @throws \Exception
     */
    public function getUserKey(string $userId): string {
        /**
         * If we have the key in the cache, just return it
         */
        if(isset($this->userKeyCache[ $userId ])) {
            return $this->userKeyCache[ $userId ];
        }

        /**
         * Read the encrypted user key from the registry
         */
        $encryptedUserKey = $this->config->getUserValue($userId, $this->appName, self::CONFIG_PATH);
        if(empty($encryptedUserKey)) {
            /**
             * If there is no user key in the config, create a new one and return that
             */
            return $this->createUserKey($userId);
        }

        /**
         * Fetch the server secret from Nextcloud.
         */
        $serverSecret = $this->config->getSystemValue('secret');

        /**
         * Use the Nextcloud encryption api to decrypt the encrypted user key value from the registry with the server secret.
         */
        $key = $this->crypto->decrypt($encryptedUserKey, $serverSecret);

        /**
         * Cache the user key for the current request.
         */
        $this->userKeyCache[ $userId ] = $key;

        /**
         * Return the decrypted user key
         */
        return $key;
    }

    /**
     * Internal function to create a new key for a user that has not key yet
     *
     * @param string $userId
     *
     * @return string
     * @throws \OCP\PreConditionNotMetException
     */
    protected function createUserKey(string $userId): string {
        /**
         * Generate a secure random string as user key.
         */
        $key = $this->secureRandom->generate(self::KEY_LENGTH);

        /**
         * Fetch the server secret from Nextcloud.
         */
        $serverSecret = $this->config->getSystemValue('secret');

        /**
         * Use the Nextcloud encryption api to encrypt the user key with the server secret.
         */
        $encryptedKey = $this->crypto->encrypt($key, $serverSecret);

        /**
         * Store the encrypted user key in the registry for the user
         */
        $this->config->setUserValue($userId, $this->appName, self::CONFIG_PATH, $encryptedKey);

        /**
         * Cache the user key for the current request.
         */
        $this->userKeyCache[ $userId ] = $key;

        /**
         * Return the decrypted user key
         */
        return $key;
    }
}
