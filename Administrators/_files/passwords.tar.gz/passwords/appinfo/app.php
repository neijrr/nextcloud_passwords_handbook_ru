<?php

namespace OCA\Passwords\AppInfo;

use OCP\AppFramework\QueryException;

try {
    new \OCA\Passwords\AppInfo\Application();
} catch(QueryException $e) {
}