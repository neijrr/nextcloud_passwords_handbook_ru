OC.L10N.register(
    'passwords',
    {
        'Passwords'             : 'Passwords',
        'FolderLabel'           : 'Folder',
        'TagLabels'             : 'Tags',
        'FolderId'              : 'Folder Id',
        'TagIds'                : 'Tag Ids',
        '{count} shares'        : 'Shared {count} times',
        'Choose expiration date': 'Choose an expiration date or leave empty to share forever'
    },
    'nplurals=2; plural=(n != 1);'
);