<?php

/**
 * This file is part of the Passwords App
 * created by Marius David Wieschollek
 * and licensed under the AGPL.
 */
namespace OCA\Passwords\Db;

/**
 * Class Tag
 *
 * @package OCA\Passwords\Db
 */
class Tag extends AbstractModelEntity
{
}