<?php

/**
 * This file is part of the Passwords App
 * created by Marius David Wieschollek
 * and licensed under the AGPL.
 */
namespace OCA\Passwords\Services\Object;

use OCA\Passwords\Db\EntityInterface;
use OCA\Passwords\Db\Folder;
use OCA\Passwords\Db\FolderMapper;
use OCA\Passwords\Db\ModelInterface;
use OCA\Passwords\Db\RevisionInterface;
use OCA\Passwords\Hooks\Manager\HookManager;
/**
 * Class FolderService
 *
 * @package OCA\Passwords\Services
 */
class FolderService extends AbstractModelService
{
    const BASE_FOLDER_UUID = '00000000-0000-0000-0000-000000000000';
    /**
     * @var FolderMapper
     */
    protected $mapper;
    /**
     * @var string
     */
    protected $class = Folder::class;
    /**
     * AbstractParentEntityService constructor.
     *
     * @param string         $userId
     * @param FolderMapper $mapper
     * @param HookManager    $hookManager
     */
    public function __construct($userId = null, HookManager $hookManager, FolderMapper $mapper)
    {
        parent::__construct($userId, $hookManager, $mapper);
    }
    /**
     * @param string $uuid
     *
     * @return \OCA\Passwords\Db\EntityInterface|Folder
     *
     * @throws \OCP\AppFramework\Db\DoesNotExistException
     * @throws \OCP\AppFramework\Db\MultipleObjectsReturnedException
     */
    public function findByUuid($uuid)
    {
        if ($uuid === self::BASE_FOLDER_UUID) {
            return $this->getBaseFolder();
        }
        return parent::findByUuid($uuid);
    }
    /**
     * @param string $uuid
     *
     * @return Folder[]
     */
    public function findByParent($uuid)
    {
        return $this->mapper->getByParentFolder($uuid);
    }
    /**
     * @return Folder|ModelInterface
     */
    public function getBaseFolder()
    {
        $model = $this->createModel();
        $model->setRevision(FolderRevisionService::BASE_REVISION_UUID);
        $model->setUuid(self::BASE_FOLDER_UUID);
        return $model;
    }
    /**
     * @param ModelInterface|EntityInterface $model
     *
     * @return Folder|\OCP\AppFramework\Db\Entity
     */
    public function save(EntityInterface $model)
    {
        if ($model->getUuid() === self::BASE_FOLDER_UUID) {
            return $model;
        }
        return parent::save($model);
    }
    /**
     * @param ModelInterface|EntityInterface $entity
     * @param array                          $overwrites
     *
     * @return EntityInterface
     * @throws \Exception
     */
    public function objClone(EntityInterface $entity, array $overwrites = [])
    {
        if ($entity->getUuid() === self::BASE_FOLDER_UUID) {
            return $entity;
        }
        return parent::objClone($entity, $overwrites);
    }
    /**
     * @param ModelInterface|EntityInterface $model
     *
     * @throws \Exception
     */
    public function delete(EntityInterface $model)
    {
        if ($model->getUuid() === self::BASE_FOLDER_UUID) {
            return;
        }
        parent::delete($model);
    }
    /**
     * @param ModelInterface    $model
     * @param RevisionInterface $revision
     *
     * @throws \Exception
     */
    public function setRevision(ModelInterface $model, RevisionInterface $revision)
    {
        if ($model->getUuid() === self::BASE_FOLDER_UUID) {
            return;
        }
        parent::setRevision($model, $revision);
    }
}