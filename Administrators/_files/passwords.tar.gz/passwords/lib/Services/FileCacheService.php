<?php

/**
 * This file is part of the Passwords App
 * created by Marius David Wieschollek
 * and licensed under the AGPL.
 */
namespace OCA\Passwords\Services;

use OCP\Files\IAppData;
use OCP\Files\NotFoundException;
use OCP\Files\SimpleFS\ISimpleFile;
use OCP\Files\SimpleFS\ISimpleFolder;
/**
 * Class FileCacheService
 *
 * @package OCA\Passwords\Services
 */
class FileCacheService
{
    const DEFAULT_CACHE = 'default';
    const AVATAR_CACHE = 'avatars';
    const FAVICON_CACHE = 'favicon';
    const PREVIEW_CACHE = 'preview';
    const PASSWORDS_CACHE = 'passwords';
    /**
     * @var IAppData
     */
    protected $appData;
    /**
     * @var LoggingService
     */
    protected $logger;
    /**
     * @var string
     */
    protected $defaultCache = self::DEFAULT_CACHE;
    /**
     * FileCacheService constructor.
     *
     * @param IAppData       $appData
     * @param LoggingService $logger
     */
    public function __construct(IAppData $appData, LoggingService $logger)
    {
        $this->appData = $appData;
        $this->logger = $logger;
    }
    /**
     * @param string $cache
     *
     * @return ISimpleFolder
     * @throws \Exception
     * @throws \OCP\Files\NotPermittedException
     */
    public function getCache($cache = null)
    {
        $cache = $this->validateCacheName($cache);
        try {
            return $this->appData->getFolder($cache . 'Cache');
        } catch (NotFoundException $e) {
            return $this->appData->newFolder($cache . 'Cache');
        }
    }
    /**
     * @param null $cache
     *
     * @return array
     * @throws \Exception
     * @throws \OCP\Files\NotPermittedException
     */
    public function getCacheInfo($cache = null)
    {
        $cache = $this->validateCacheName($cache);
        $fileCache = $this->getCache($cache);
        $cachedFiles = $fileCache->getDirectoryListing();
        $info = ['name' => $cache, 'size' => 0, 'files' => 0];
        foreach ($cachedFiles as $file) {
            $info['size'] += $file->getSize();
            $info['files']++;
        }
        return $info;
    }
    /**
     * @return array
     */
    public function listCaches()
    {
        return [self::DEFAULT_CACHE, self::AVATAR_CACHE, self::FAVICON_CACHE, self::PREVIEW_CACHE, self::PASSWORDS_CACHE];
    }
    /**
     * @param string $cache
     *
     * @return bool
     */
    public function hasCache($cache)
    {
        return in_array($cache, $this->listCaches());
    }
    /**
     * @param string $cache
     *
     * @return string
     * @throws \Exception
     */
    protected function validateCacheName($cache = null)
    {
        if ($cache === null) {
            return $this->defaultCache;
        }
        if (!$this->hasCache($cache)) {
            throw new \Exception('Unknown Cache ' . $cache);
        }
        return $cache;
    }
    /**
     * @param string $cache
     */
    public function clearCache($cache = null)
    {
        try {
            $cache = $this->validateCacheName($cache);
            $this->getCache($cache)->delete();
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
    }
    /**
     *
     */
    public function clearAllCaches()
    {
        $caches = $this->listCaches();
        foreach ($caches as $cache) {
            $this->clearCache($cache);
        }
    }
    /**
     * @param string $cache
     *
     * @return bool
     */
    public function isCacheEmpty($cache = null)
    {
        try {
            $info = $this->getCacheInfo($cache);
            return $info['files'] == 0;
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
        return true;
    }
    /**
     * @param string $file
     * @param string $cache
     *
     * @return bool
     */
    public function hasFile($file, $cache = null)
    {
        try {
            $cache = $this->validateCacheName($cache);
            return $this->getCache($cache)->fileExists($file);
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
        return false;
    }
    /**
     * @param string $file
     * @param string $cache
     *
     * @return ISimpleFile
     */
    public function getFile($file, $cache = null)
    {
        try {
            $cache = $this->validateCacheName($cache);
            $cache = $this->getCache($cache);
            if ($cache->fileExists($file)) {
                return $cache->getFile($file);
            }
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
        return null;
    }
    /**
     * @param string $file
     * @param string $content
     * @param string $cache
     *
     * @return ISimpleFile|null
     */
    public function putFile($file, $content, $cache = null)
    {
        try {
            $cache = $this->validateCacheName($cache);
            $cache = $this->getCache($cache);
            if ($cache->fileExists($file)) {
                $fileModel = $cache->getFile($file);
            } else {
                $fileModel = $cache->newFile($file);
            }
            $fileModel->putContent($content);
            return $fileModel;
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
        return null;
    }
    /**
     * @param string $file
     * @param string $cache
     */
    public function removeFile($file, $cache = null)
    {
        try {
            $cache = $this->validateCacheName($cache);
            $this->getFile($file, $cache)->delete();
        } catch (\Throwable $e) {
            $this->logger->logException($e);
        }
    }
    /**
     * @param string $cache
     *
     * @return FileCacheService
     */
    public function getCacheService($cache = self::DEFAULT_CACHE)
    {
        if (!$this->hasCache($cache)) {
            $cache = self::DEFAULT_CACHE;
        }
        $service = clone $this;
        $service->setDefaultCache($cache);
        return $service;
    }
    /**
     * @param string $defaultCache
     */
    protected function setDefaultCache($defaultCache = self::DEFAULT_CACHE)
    {
        $this->defaultCache = $defaultCache;
    }
}